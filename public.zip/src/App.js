import LoginPage from "./user_pages/userlogin";
import {Link} from 'react-router-dom';


function App() {
  return (
    <div className="App">
   <Link to="/userlogin">go to login page</Link>
    </div>
  );
}

export default App;
