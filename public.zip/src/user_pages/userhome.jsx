import axios from "axios";
import { useEffect, useState } from "react";
import React from "react";


function UserHomePage(){

  useEffect({
   try {
     const response = axios.get("")
   } catch (error) {
    
   }
  },[])


}