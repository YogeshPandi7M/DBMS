import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function UserRegistration() {
    const navigate = useNavigate()
  
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        password: '',
        phone_number: '',
        address: {
            street: '',
            city: '',
            zip: '',
            state: '',
        },
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        
        if (['street', 'city', 'zip', 'state'].includes(name)) {
            setFormData((prevData) => ({
                ...prevData,
                address: {
                    ...prevData.address,
                    [name]: value,
                },
            }));
        } else {
            setFormData((prevData) => ({
                ...prevData,
                [name]: value,
            }));
        }
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:4000/addnewuser', formData);
            alert(response.data.message); // Assuming backend sends a success message

            if (response.data.message === "User Added Successfully")
                 navigate("/userhome")
        } catch (error) {
            console.error('Error submitting form:', error);
            alert('Registration failed. Please try again.');
        }
    };

    return (
        <div>
            <h2>User Registration</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label>Name:</label>
                    <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        required
                    />
                </div>
                
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                    />
                </div>
                
                <div>
                    <label>Password:</label>
                    <input
                        type="password"
                        name="password"
                        value={formData.password}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label>Phone Number:</label>
                    <input
                        type="text"
                        name="phone_number"
                        value={formData.phone_number}
                        onChange={handleChange}
                        required
                    />
                </div>

                <h3>Address</h3>
                <div>
                    <label>Street:</label>
                    <input
                        type="text"
                        name="street"
                        value={formData.address.street}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label>City:</label>
                    <input
                        type="text"
                        name="city"
                        value={formData.address.city}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label>Zip Code:</label>
                    <input
                        type="text"
                        name="zip"
                        value={formData.address.zip}
                        onChange={handleChange}
                        required
                    />
                </div>

                <div>
                    <label>State:</label>
                    <input
                        type="text"
                        name="state"
                        value={formData.address.state}
                        onChange={handleChange}
                        required
                    />
                </div>

                <button type="submit">Register</button>
            </form>
        </div>
    );
}

export default UserRegistration;
